const tok = () => sessionStorage.getItem("token") || localStorage.getItem("token");
async function call(method, path, data) {
  const r = await fetch("/api/" + path, { method, headers: { "Content-Type": "application/json", Authorization: "Bearer " + tok() }, body: data ? JSON.stringify(data) : undefined });
  const j = await r.json().catch(() => ({}));
  if (r.status === 401) { sessionStorage.clear(); localStorage.removeItem("token"); location.href = "index.html"; throw new Error("Sessão expirada"); }
  if (!r.ok) throw new Error(j.error || "Erro");
  return j;
}
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const MATERIAS = [
  { nome: "Matemática", icone: "🔢", cor: "#1e6fff" }, { nome: "Português", icone: "📖", cor: "#ff6b6b" },
  { nome: "Ciências", icone: "🔬", cor: "#2ecc71" }, { nome: "História", icone: "🏛️", cor: "#e0a100" },
  { nome: "Geografia", icone: "🌎", cor: "#00a8c6" }, { nome: "Raciocínio Lógico", icone: "🧩", cor: "#7c4dff" },
];
async function sair() { sessionStorage.clear(); localStorage.removeItem("token"); try { if (typeof limparPerfil === "function") await limparPerfil(); } catch {} location.href = "index.html"; }
if (!tok()) location.href = "index.html";
